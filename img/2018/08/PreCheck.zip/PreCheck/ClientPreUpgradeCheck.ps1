﻿Remove-Variable * -ErrorAction SilentlyContinue
#https://technet.microsoft.com/de-de/aa366320
Add-Type -AssemblyName PresentationCore,PresentationFramework

$Global:AllValid = $false
$Global:USBConnected = $null
$Global:OnBattery = $null
$Global:WirelessConnected = $null
$Global:WiredConnected = $null
$Global:VPNConnected = $null


Function Check-Statuses
{

    $Global:USBConnected = (Get-WmiObject Win32_LogicalDisk | Where-Object DriveType -eq 2) -ne $null

    $Global:OnBattery = (Get-WMIObject Win32_Battery | Where-Object batterystatus -ne $null) -and ((Get-WMIObject Win32_Battery | Where-Object BatteryStatus -eq 2) -eq $null)

    $NetworkConfiguration = Get-WmiObject Win32_NetworkAdapterConfiguration
    $WirelessAdapters = Get-WmiObject -Class MSNdis_PhysicalMediumType -Namespace "root\WMI" | Where-Object NdisPhysicalMediumType -eq 9
    $WiredAdapters = Get-WmiObject -Class MSNdis_PhysicalMediumType -Namespace "root\WMI" | Where-Object NdisPhysicalMediumType -eq 0
    $ConnectedAdapters = Get-WmiObject win32_networkadapter | Where-Object NetConnectionStatus -eq "2"
    $VPNAdapters = $NetworkConfiguration | Where-Object {(($_.Description -ilike "*pangp*") -or ($_.Description -ilike "*cisco*"))}

    Foreach($Adapter in $ConnectedAdapters) {
        If($WirelessAdapters.InstanceName -contains $Adapter.ProductName)
        {
            $Global:WirelessConnected = $true
        }
    }

    Foreach($Adapter in $ConnectedAdapters) {
        If($WiredAdapters.InstanceName -contains $Adapter.ProductName)
        {
            $Global:WiredConnected = $true
        }
    }

    Foreach($Adapter in $ConnectedAdapters) {
        If($VPNAdapters.Index -contains $Adapter.DeviceID)
        {
            $Global:VPNConnected = $true
        }
    }
}

Function Display-Message ($USBConnected, $OnBattery, $WirelessConnected, $WiredConnected,$VPNConnected)
{

    Try
    {
        $TSProgressUI = new-object -comobject Microsoft.SMS.TSProgressUI
        $TSProgressUI.CloseProgressDialog()
        $TSProgressUI = $null
    } 
    Catch
    {
  
    }


    $AdapterFriendlyText = "No Status"
    $AdapterWirelessText = "Please plug into a LAN connection."
    $AdapterVPNText = "VPN Connected. Upgrade cannot proceed on VPN."
    $AdapterNotConnectedText = "No network connection found. Please connect to a LAN connection and try again."
    $AdapterOKText = "Passed"
    
    $USBFriendlyText = "No Status"
    $USBConnectedText = "Please unplug any USB Drives and try again."
    $USBOKText = "Passed"

    $BatteryFriendlyText = "No Status"
    $BatteryOnBatteryText = "Please plug into AC Power and try again."
    $BatteryOKText = "Passed"

    

    $USBFriendlyText = switch($USBConnected)
    {
        $true {$USBConnectedText; break;}
        $false {$USBOKText; break;}
    }

    $BatteryFriendlyText = switch($OnBattery)
    {
        $true {$BatteryOnBatteryText; break;}
        $false {$BatteryOKText; break;}
    }

    If($VPNConnected)
    {
        $AdapterFriendlyText = $AdapterVPNText
    }
    ElseIf($WirelessConnected -and !$WiredConnected)
    {
        $AdapterFriendlyText = $AdapterWirelessText
    }
    ElseIf($WiredConnected -and !$VPNConnected)
    {
        $AdapterFriendlyText = $AdapterOKText
    }
    Else
    {
        $AdapterFriendlyText = $AdapterNotConnectedText
    }
   
    $ButtonType = [System.Windows.MessageBoxButton]::OKCancel
    $MessageboxTitle = “Windows 10 Pre-Check”
$Messageboxbody = @"
   
   Network Status = $($AdapterFriendlyText)

   Battery Status = $($BatteryFriendlyText)
   
   External Drive Status = $($USBFriendlyText)
          
   After addressing the issue(s) above

   Click OK to Continue or Click Cancel to Exit
"@


    $MessageIcon = [System.Windows.MessageBoxImage]::Warning
    $oReturn=[System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

    switch ($oReturn){
        "OK" {Return $True}
        "Cancel"{Return $False}
    }

}

Function Display-ErrorMessage
{
    $ButtonType = [System.Windows.MessageBoxButton]::OK
    $MessageboxTitle = “Windows 10 Pre-Check”
    $Messageboxbody = "Pre-Check was cancelled or exceed max retires. Please try again later."

    $MessageIcon = [System.Windows.MessageBoxImage]::Warning
    $oReturn=[System.Windows.MessageBox]::Show($Messageboxbody,$MessageboxTitle,$ButtonType,$messageicon)

    switch ($oReturn){
        "OK" {Return}
    }
}

Function Process-Checks
{
    $ReturnCode = 1

    $Counter = 0
    While((($Global:AllValid -eq $false) -and ($Counter -le 4)))
    {
        $Counter++
        $Global:USBConnected = $null
        $Global:OnBattery = $null
        $Global:WirelessConnected = $null
        $Global:WiredConnected = $null
        $Global:VPNConnected = $null

        Check-Statuses

        $Global:AllValid = (!$Global:USBConnected -and !$Global:OnBattery -and !$Globl:VPNConnected -and $Global:WiredConnected)

        If (!$Global:AllValid)
        {
            $Result = Display-Message $Global:USBConnected $Global:OnBattery $Global:WirelessConnected $Global:WiredConnected $Global:VPNConnected
            If(!$Result)
            {
                #User Cancelled
                Display-ErrorMessage | Out-Null
                $ReturnCode = 1
                break;
            }
        }
        Else
        {
            Try
            {
                $TSProgressUI = new-object -comobject Microsoft.SMS.TSProgressUI
                $TSProgressUI.ShowTSProgress($tsenv.Value("_SMSTSOrgName"), $tsenv.Value("_SMSTSPackageName"), $tsenv.Value("_SMSTSCustomProgressDialogMessage"), $tsenv.Value("_SMSTSCurrentActionName"), $tsenv.Value("_SMSTSNextInstructionPointer"),  $tsenv.Value("_SMSTSInstructionTableSize")) 
                $TSProgressUI = $null
            } 
            Catch
            {
  
            }
         
            $ReturnCode = 0
        }
    }

    If(!$Global:AllValid -and $Counter -ge 4)
    {
        #Too Many Loops
        Display-ErrorMessage | Out-Null
        $ReturnCode = 1
    }
   
    Return $ReturnCode
}

$ExitCode = Process-Checks

Write-Host "Exiting with ExitCode $($ExitCode)"

Exit $ExitCode